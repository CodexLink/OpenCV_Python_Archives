# python3

from os import getcwd, path
from os.path import isfile
from subprocess import Popen
from sys import exit
from time import sleep
from tkinter import Image, Tk
from tkinter.filedialog import askopenfilename
from typing import Final, NewType, Text, Tuple

from cv2 import (
    COLOR_BGR2GRAY,
    HOUGH_GRADIENT,
    HOUGH_GRADIENT_ALT,
    GaussianBlur,
    HoughCircles,
    circle,
    createCLAHE,
    cvtColor,
    destroyAllWindows,
    equalizeHist,
    imread,
    imshow,
    imwrite,
    medianBlur,
    rectangle,
    waitKey,
    Canny,
)
from numpy import ndarray, round, vectorize

# Constant Variables
FILE_TYPES: Final = [("Image Files (.jpeg .jpg .png)", ".jpeg .jpg .png")]
DEFAULT_EXT: Final = ".jpg"
FILE_DIALOG_TITLE: Final = "Load an Image File To Process..."

# Static Typing Variables
ImageBuffer: Final = NewType("ImageBuffer", ndarray)


class DetectionAssignment(object):
    def __init__(self, **kwargs: dict) -> None:
        window = Tk()
        window.attributes("-topmost", True)
        window.withdraw()

        # Instantiate State Class Variables
        self.image_save_filename: Text = None

        # self.error_msg : str = None

        # Constructor Style for Class Instantiation
        Popen("CLS", shell=True).communicate()
        print(
            "Blood Sample Count based from Image\nCreated by Group 5 of Machine Perception.",
            end="\n\n",
        )

    def entrypoint(self: object) -> int:
        print(
            "Wait for the File Manager / File Explorer To Open. And select an image file...",
        )
        image_path = askopenfilename(
            title=FILE_DIALOG_TITLE,
            defaultextension=DEFAULT_EXT,
            filetypes=FILE_TYPES,
        )

        if not isfile(image_path) or not len(image_path):
            return 0

        print("File is Valid. Processing the Image...", end="\n\n")

        print("Enhancing the Image...")
        enhancement_buffer = self.image_enhancement(image_path)

        print("Processing the Enhanced Image...")
        self.image_process(enhancement_buffer)

        print(
            "Image Processing Finished. Close the Window to remove blocking on the script."
        )

    # * Step 1
    # No parameters can be given from this function! Please modify the definition accordingly.
    def image_enhancement(self, img_path: Text) -> ImageBuffer:
        print("Enhancement | Step 0 | Original Image Reading to Numpy Array.")
        img_buffer = imread(img_path)

        print("Enhancement | Step 1 | Grayscale")
        img_buffer = cvtColor(img_buffer, COLOR_BGR2GRAY)

        print("Enhancement | Step 2 | Blurring with Median and Gausian")
        img_buffer = medianBlur(img_buffer, 3)
        # imshow("Last Known from medianBlur", img_buffer)
        img_buffer = GaussianBlur(img_buffer, (7, 7), 0)
        # imshow("Last Known from GaussianBlur", img_buffer)

        print("Enhancement | Step 3 | Histogram Equalization")
        img_buffer = equalizeHist(img_buffer)

        print("Enhancement | Step 4 | CLAHE Implementation")
        clahe_buffer = createCLAHE(clipLimit=1.5, tileGridSize=(8, 8))
        clahe_apply_buffer = clahe_buffer.apply(img_buffer)

        # print("Enhancement | Step 4 | Vectorization")
        # pixel_vector = vectorize(self.pixelVal)
        # contrast_buffer = pixel_vector(clahe_apply_buffer, 70, 0, 200, 255)

        print("Enhancement Done...")
        # edge = Canny(img_buffer, 100, 200)
        # edge1 = Canny(clahe_apply_buffer, 100, 200)
        # # imshow("From Clahe", clahe_apply_buffer)
        # # imshow("Last Known from Equalization", img_buffer)
        # imshow("From Clahe", edge)
        # imshow("Last Known from Equalization", edge1)
        # waitKey(0)
        # destroyAllWindows()
        # exit(0)
        return clahe_apply_buffer

    # * Step 2
    def image_process(self: object, enhanced_img_buffer: ImageBuffer) -> None:

        # Block-Level State Variable
        rbc_count : int = 0
        circle_algo_buffer = HoughCircles(
            enhanced_img_buffer,
            HOUGH_GRADIENT,
            1.1989,
            20,
            param1=75,
            param2=25,
            minRadius=15,
            maxRadius=35, # 122 on blood cells on 15. # 15, 35 best for last picture
        )

        if circle_algo_buffer is not None:
            detected_rbc_context = round(circle_algo_buffer[0, :]).astype("int")

            for (x, y, r) in detected_rbc_context:
                circle(enhanced_img_buffer, (x, y), r, (255, 255, 0), 2)
                rectangle(
                    enhanced_img_buffer,
                    (x - 2, y - 2),
                    (x + 2, y + 2),
                    (255, 128, 255),
                    -1,
                )
                rbc_count += 1


            imshow(f"RBC Count is {rbc_count}", enhanced_img_buffer)
            waitKey(0)
            destroyAllWindows()

            exit(0)


        raise SystemError(
            "The function `image_process()` expects the buffer to be a type ImageBuffer with context! Please debug this before trying again."
        )

    # * Post-Step
    def post_process_prompt(
        self,
    ) -> Tuple[bool, bool]:
        prompt_1 = bool(input("Do you want to save the modification result?"))
        prompt_2 = bool(input("Do yo want to re-run this script again?"))
        return prompt_1, prompt_2

    # * Extra
    # def pixelVal(self: object, pix: int, r1: int, s1: int, r2: int, s2: int) -> int:
    #     if 0 <= pix and pix <= r1:
    #         return (s1 / r1) * pix
    #     elif r1 < pix and pix <= r2:
    #         return ((s2 - s1) / (r2 - r1)) * (pix - r1) + s1
    #     else:
    #         return ((255 - s2) / (255 - r2)) * (pix - r2) + s2


if __name__ == "__main__":
    inst = DetectionAssignment()
    entrypoint = (
        inst.entrypoint()
    )  # While Loop is here, no need to handle entrypoint code.
    raise SystemExit(f"Operation Finished. Thank you. Return Code is {entrypoint}")

raise ImportError("You cannot import this file to other examples!")
